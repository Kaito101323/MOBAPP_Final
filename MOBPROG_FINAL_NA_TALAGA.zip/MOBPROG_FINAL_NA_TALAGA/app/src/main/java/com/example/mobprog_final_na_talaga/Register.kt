package com.example.mobprog_final_na_talaga

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton

class Register : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        Log.d("Register", "Register Activity started") // Debug log

        dbHelper = DatabaseHelper(this)

        val firstNameEditText = findViewById<EditText>(R.id.First_Name)
        val lastNameEditText = findViewById<EditText>(R.id.Last_Name)
        val usernameEditText = findViewById<EditText>(R.id.RUsername)
        val emailEditText = findViewById<EditText>(R.id.REmail)
        val passwordEditText = findViewById<EditText>(R.id.RPassword)
        val registerButton = findViewById<MaterialButton>(R.id.Register)

        // Adjust layout for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Hide keyboard when pressing "Enter"
        setupKeyboardHiding(firstNameEditText, lastNameEditText, usernameEditText, emailEditText, passwordEditText)

        // Handle register button click
        registerButton.setOnClickListener {
            registerUser(
                firstNameEditText.text.toString().trim(),
                lastNameEditText.text.toString().trim(),
                usernameEditText.text.toString().trim(),
                emailEditText.text.toString().trim(),
                passwordEditText.text.toString().trim()
            )
        }
    }

    private fun registerUser(firstName: String, lastName: String, username: String, email: String, password: String) {
        if (firstName.isNotEmpty() && lastName.isNotEmpty() && username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
            if (dbHelper.isUsernameExists(username)) {
                Toast.makeText(this, "Username already exists. Please choose a different username.", Toast.LENGTH_SHORT).show()
            } else {
                val result = dbHelper.insertUser(
                    firstName = firstName,
                    lastName = lastName,
                    email = email,
                    username = username,
                    password = password,
                    dateOfBirth = "",
                    gender = "",
                    weight = 0.0f,
                    targetWeight = 0.0f,
                    age = 0,
                    height = 0.0f,
                    goalId = 1
                )

                if (result > -1) {
                    Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
                    navigateToGenderSelection(username)
                } else {
                    Toast.makeText(this, "Registration failed. Try again.", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToGenderSelection(username: String) {
        val intent = Intent(this, Gender::class.java)
        intent.putExtra("USERNAME", username)  // Pass username to the Gender activity
        startActivity(intent)
        finish()  // Close the Register activity
    }

    private fun setupKeyboardHiding(vararg editTexts: EditText) {
        for (editText in editTexts) {
            editText.setOnEditorActionListener { v, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_DONE ||
                    actionId == EditorInfo.IME_ACTION_NEXT ||
                    event?.keyCode == KeyEvent.KEYCODE_ENTER) {

                    // Cast 'v' to EditText
                    hideKeyboard(v as EditText)
                    v.clearFocus() // Remove focus from EditText
                    return@setOnEditorActionListener true
                }
                false
            }
        }
    }


    private fun hideKeyboard(view: EditText) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }
}
